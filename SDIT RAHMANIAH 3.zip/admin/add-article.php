<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once '../api/config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $excerpt = trim($_POST['excerpt'] ?? '');
    $category = $_POST['category'] ?? 'Kegiatan';
    $status = $_POST['status'] ?? 'published';
    
    // Handle image upload
    $image = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../assets/Artikel/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileName = time() . '_' . basename($_FILES['image']['name']);
        $filePath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $filePath)) {
            $image = 'assets/Artikel/' . $fileName;
        } else {
            $error = 'Gagal mengupload gambar';
        }
    }
    
    if (empty($title) || empty($content)) {
        $error = 'Judul dan konten harus diisi';
    } else {
        if (empty($excerpt)) {
            $excerpt = substr(strip_tags($content), 0, 200) . '...';
        }
        
        $stmt = $conn->prepare("INSERT INTO articles (title, content, excerpt, image, category, status, author_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssi", $title, $content, $excerpt, $image, $category, $status, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            $success = 'Artikel berhasil ditambahkan';
            // Clear form
            $title = $content = $excerpt = '';
        } else {
            $error = 'Gagal menambahkan artikel';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Artikel — SDIT Rahmaniyah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            background: var(--bg);
            min-height: 100vh;
        }
        .admin-header {
            background: var(--navy);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
        }
        .form-container {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 40px;
            border-radius: 16px;
            border: 1px solid var(--line);
        }
        .form-group {
            margin-bottom: 24px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--navy);
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--line);
            border-radius: 8px;
            font-size: 15px;
            font-family: inherit;
        }
        .form-group textarea {
            min-height: 300px;
            resize: vertical;
        }
        .btn-submit {
            background: var(--navy);
            color: white;
            padding: 14px 28px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-submit:hover {
            background: #1e3a8a;
        }
        .error {
            background: #fee2e2;
            color: #dc2626;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .success {
            background: #dcfce7;
            color: #166534;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>Tambah Artikel Baru</h1>
        <div class="admin-nav">
            <a href="dashboard.php">← Kembali ke Dashboard</a>
        </div>
    </div>
    
    <div class="form-container">
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Judul Artikel *</label>
                <input type="text" id="title" name="title" required value="<?php echo htmlspecialchars($title ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="category">Kategori</label>
                <select id="category" name="category">
                    <option value="Kegiatan" <?php echo ($category ?? '') === 'Kegiatan' ? 'selected' : ''; ?>>Kegiatan</option>
                    <option value="Prestasi" <?php echo ($category ?? '') === 'Prestasi' ? 'selected' : ''; ?>>Prestasi</option>
                    <option value="Pembelajaran" <?php echo ($category ?? '') === 'Pembelajaran' ? 'selected' : ''; ?>>Pembelajaran</option>
                    <option value="Pengumuman" <?php echo ($category ?? '') === 'Pengumuman' ? 'selected' : ''; ?>>Pengumuman</option>
                    <option value="Profil" <?php echo ($category ?? '') === 'Profil' ? 'selected' : ''; ?>>Profil</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="excerpt">Ringkasan (Excerpt)</label>
                <input type="text" id="excerpt" name="excerpt" value="<?php echo htmlspecialchars($excerpt ?? ''); ?>">
                <small style="color: var(--ink-muted);">Jika kosong, akan diambil dari konten</small>
            </div>
            
            <div class="form-group">
                <label for="image">Gambar</label>
                <input type="file" id="image" name="image" accept="image/*">
                <small style="color: var(--ink-muted);">Format: JPG, JPEG, PNG, JFIF</small>
            </div>
            
            <div class="form-group">
                <label for="content">Konten Artikel *</label>
                <textarea id="content" name="content" required><?php echo htmlspecialchars($content ?? ''); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="published" <?php echo ($status ?? '') === 'published' ? 'selected' : ''; ?>>Terbit</option>
                    <option value="draft" <?php echo ($status ?? '') === 'draft' ? 'selected' : ''; ?>>Draft</option>
                </select>
            </div>
            
            <button type="submit" class="btn-submit">Simpan Artikel</button>
        </form>
    </div>
</body>
</html>
