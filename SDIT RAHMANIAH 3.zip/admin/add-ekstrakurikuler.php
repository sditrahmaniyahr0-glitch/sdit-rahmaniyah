<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once '../api/config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $schedule = trim($_POST['schedule'] ?? '');
    $age_range = trim($_POST['age_range'] ?? '');
    $instructor = trim($_POST['instructor'] ?? '');
    $status = $_POST['status'] ?? 'published';
    
    $image = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../assets/Artikel/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileName = time() . '_' . basename($_FILES['image']['name']);
        $filePath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $filePath)) {
            $image = 'assets/Artikel/' . $fileName;
        } else {
            $error = 'Gagal mengupload gambar';
        }
    }
    
    if (empty($name) || empty($description)) {
        $error = 'Nama dan deskripsi harus diisi';
    } else {
        $stmt = $conn->prepare("INSERT INTO ekstrakurikuler (name, description, image, schedule, age_range, instructor, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $name, $description, $image, $schedule, $age_range, $instructor, $status);
        
        if ($stmt->execute()) {
            $success = 'Ekstrakurikuler berhasil ditambahkan';
            $name = $description = $schedule = $age_range = $instructor = '';
        } else {
            $error = 'Gagal menambahkan ekstrakurikuler';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Ekstrakurikuler — SDIT Rahmaniyah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            background: var(--bg);
            min-height: 100vh;
        }
        .admin-header {
            background: var(--navy);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
        }
        .form-container {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 40px;
            border-radius: 16px;
            border: 1px solid var(--line);
        }
        .form-group {
            margin-bottom: 24px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--navy);
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--line);
            border-radius: 8px;
            font-size: 15px;
            font-family: inherit;
        }
        .form-group textarea {
            min-height: 150px;
            resize: vertical;
        }
        .btn-submit {
            background: var(--navy);
            color: white;
            padding: 14px 28px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-submit:hover {
            background: #1e3a8a;
        }
        .error {
            background: #fee2e2;
            color: #dc2626;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .success {
            background: #dcfce7;
            color: #166534;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>Tambah Ekstrakurikuler Baru</h1>
        <div class="admin-nav">
            <a href="dashboard.php">← Kembali ke Dashboard</a>
        </div>
    </div>
    
    <div class="form-container">
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Nama Ekstrakurikuler *</label>
                <input type="text" id="name" name="name" required value="<?php echo htmlspecialchars($name ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="description">Deskripsi *</label>
                <textarea id="description" name="description" required><?php echo htmlspecialchars($description ?? ''); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="schedule">Jadwal</label>
                <input type="text" id="schedule" name="schedule" value="<?php echo htmlspecialchars($schedule ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="age_range">Rentang Usia</label>
                <input type="text" id="age_range" name="age_range" value="<?php echo htmlspecialchars($age_range ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="instructor">Pembina</label>
                <input type="text" id="instructor" name="instructor" value="<?php echo htmlspecialchars($instructor ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="image">Gambar</label>
                <input type="file" id="image" name="image" accept="image/*">
            </div>
            
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="published" <?php echo ($status ?? '') === 'published' ? 'selected' : ''; ?>>Terbit</option>
                    <option value="draft" <?php echo ($status ?? '') === 'draft' ? 'selected' : ''; ?>>Draft</option>
                </select>
            </div>
            
            <button type="submit" class="btn-submit">Simpan Ekstrakurikuler</button>
        </form>
    </div>
</body>
</html>
