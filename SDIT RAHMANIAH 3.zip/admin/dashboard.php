<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once '../api/config.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin — SDIT Rahmaniyah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            background: var(--bg);
            min-height: 100vh;
        }
        .admin-header {
            background: var(--navy);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-header h1 {
            margin: 0;
            font-size: 24px;
        }
        .admin-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .admin-nav a {
            color: white;
            text-decoration: none;
            font-weight: 500;
        }
        .admin-nav a:hover {
            text-decoration: underline;
        }
        .btn-logout {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
        }
        .btn-logout:hover {
            background: rgba(255,255,255,0.3);
            text-decoration: none;
        }
        .dashboard-content {
            padding: 40px;
            max-width: 1400px;
            margin: 0 auto;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
            margin-bottom: 40px;
        }
        .stat-card {
            background: white;
            padding: 32px;
            border-radius: 16px;
            border: 1px solid var(--line);
        }
        .stat-card h3 {
            font-size: 48px;
            color: var(--gold);
            margin: 0 0 8px 0;
        }
        .stat-card p {
            color: var(--ink-muted);
            margin: 0;
        }
        .content-section {
            background: white;
            padding: 32px;
            border-radius: 16px;
            border: 1px solid var(--line);
            margin-bottom: 40px;
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }
        .section-header h2 {
            margin: 0;
        }
        .btn-add {
            background: var(--teal);
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
        }
        .btn-add:hover {
            background: #0d9488;
            text-decoration: none;
            color: white;
        }
        .articles-table {
            width: 100%;
            background: white;
            border-radius: 16px;
            border: 1px solid var(--line);
            overflow: hidden;
        }
        .articles-table th,
        .articles-table td {
            padding: 16px;
            text-align: left;
            border-bottom: 1px solid var(--line);
        }
        .articles-table th {
            background: var(--bg);
            font-weight: 600;
        }
        .articles-table tr:last-child td {
            border-bottom: none;
        }
        .status-badge {
            padding: 4px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-published {
            background: #dcfce7;
            color: #166534;
        }
        .status-draft {
            background: #fef3c7;
            color: #92400e;
        }
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        .btn-edit {
            background: #e0f2fe;
            color: #0369a1;
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 13px;
        }
        .btn-delete {
            background: #fee2e2;
            color: #dc2626;
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 13px;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>Dashboard Admin SDIT Rahmaniyah</h1>
        <div class="admin-nav">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
            <a href="logout.php" class="btn-logout">Logout</a>
        </div>
    </div>
    
    <div class="dashboard-content">
        <div class="stats-grid">
            <div class="stat-card">
                <?php
                $result = $conn->query("SELECT COUNT(*) as total FROM articles");
                $row = $result->fetch_assoc();
                ?>
                <h3><?php echo $row['total']; ?></h3>
                <p>Total Artikel</p>
            </div>
            <div class="stat-card">
                <?php
                $result = $conn->query("SELECT COUNT(*) as total FROM ekstrakurikuler");
                $row = $result->fetch_assoc();
                ?>
                <h3><?php echo $row['total']; ?></h3>
                <p>Total Ekstrakurikuler</p>
            </div>
            <div class="stat-card">
                <?php
                $result = $conn->query("SELECT COUNT(*) as total FROM programs");
                $row = $result->fetch_assoc();
                ?>
                <h3><?php echo $row['total']; ?></h3>
                <p>Total Program</p>
            </div>
            <div class="stat-card">
                <?php
                $result = $conn->query("SELECT SUM(views) as total FROM articles");
                $row = $result->fetch_assoc();
                ?>
                <h3><?php echo $row['total'] ?? 0; ?></h3>
                <p>Total Views</p>
            </div>
        </div>
        
        <!-- Ekstrakurikuler Section -->
        <div class="content-section">
            <div class="section-header">
                <h2>Ekstrakurikuler</h2>
                <a href="add-ekstrakurikuler.php" class="btn-add">+ Tambah Ekstrakurikuler</a>
            </div>
            <table class="articles-table">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Jadwal</th>
                        <th>Pembina</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = $conn->query("SELECT * FROM ekstrakurikuler ORDER BY created_at DESC LIMIT 5");
                    while ($row = $result->fetch_assoc()):
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['schedule'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($row['instructor'] ?? '-'); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $row['status']; ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="edit-ekstrakurikuler.php?id=<?php echo $row['id']; ?>" class="btn-edit">Edit</a>
                                <a href="delete-ekstrakurikuler.php?id=<?php echo $row['id']; ?>" class="btn-delete" onclick="return confirm('Yakin ingin menghapus ekstrakurikuler ini?')">Hapus</a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Programs Section -->
        <div class="content-section">
            <div class="section-header">
                <h2>Program Unggulan</h2>
                <a href="add-program.php" class="btn-add">+ Tambah Program</a>
            </div>
            <table class="articles-table">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Icon</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = $conn->query("SELECT * FROM programs ORDER BY created_at DESC LIMIT 5");
                    while ($row = $result->fetch_assoc()):
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['icon'] ?? '-'); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $row['status']; ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="edit-program.php?id=<?php echo $row['id']; ?>" class="btn-edit">Edit</a>
                                <a href="delete-program.php?id=<?php echo $row['id']; ?>" class="btn-delete" onclick="return confirm('Yakin ingin menghapus program ini?')">Hapus</a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Articles Section -->
        <div class="content-section">
            <div class="section-header">
                <h2>Artikel Terbaru</h2>
                <a href="add-article.php" class="btn-add">+ Tambah Artikel</a>
            </div>
            <table class="articles-table">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Status</th>
                        <th>Views</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = $conn->query("SELECT * FROM articles ORDER BY created_at DESC LIMIT 5");
                    while ($row = $result->fetch_assoc()):
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['category']); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $row['status']; ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td><?php echo $row['views']; ?></td>
                        <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                        <td>
                            <div class="action-buttons">
                                <a href="edit-article.php?id=<?php echo $row['id']; ?>" class="btn-edit">Edit</a>
                                <a href="delete-article.php?id=<?php echo $row['id']; ?>" class="btn-delete" onclick="return confirm('Yakin ingin menghapus artikel ini?')">Hapus</a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
