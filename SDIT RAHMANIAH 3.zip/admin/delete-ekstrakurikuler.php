<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once '../api/config.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: dashboard.php');
    exit;
}

$stmt = $conn->prepare("DELETE FROM ekstrakurikuler WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header('Location: dashboard.php?deleted=1');
    exit;
} else {
    header('Location: dashboard.php?error=1');
    exit;
}
?>
