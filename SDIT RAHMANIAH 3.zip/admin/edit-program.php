<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once '../api/config.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: dashboard.php');
    exit;
}

$stmt = $conn->prepare("SELECT * FROM programs WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: dashboard.php');
    exit;
}

$program = $result->fetch_assoc();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $icon = trim($_POST['icon'] ?? '');
    $details = trim($_POST['details'] ?? '');
    $status = $_POST['status'] ?? 'published';
    
    if (empty($title) || empty($description)) {
        $error = 'Judul dan deskripsi harus diisi';
    } else {
        $stmt = $conn->prepare("UPDATE programs SET title = ?, description = ?, icon = ?, details = ?, status = ? WHERE id = ?");
        $stmt->bind_param("sssssi", $title, $description, $icon, $details, $status, $id);
        
        if ($stmt->execute()) {
            $success = 'Program berhasil diperbarui';
            $stmt = $conn->prepare("SELECT * FROM programs WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $program = $result->fetch_assoc();
        } else {
            $error = 'Gagal memperbarui program';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Program — SDIT Rahmaniyah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            background: var(--bg);
            min-height: 100vh;
        }
        .admin-header {
            background: var(--navy);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
        }
        .form-container {
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 40px;
            border-radius: 16px;
            border: 1px solid var(--line);
        }
        .form-group {
            margin-bottom: 24px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--navy);
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--line);
            border-radius: 8px;
            font-size: 15px;
            font-family: inherit;
        }
        .form-group textarea {
            min-height: 150px;
            resize: vertical;
        }
        .btn-submit {
            background: var(--navy);
            color: white;
            padding: 14px 28px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-submit:hover {
            background: #1e3a8a;
        }
        .error {
            background: #fee2e2;
            color: #dc2626;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .success {
            background: #dcfce7;
            color: #166534;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>Edit Program</h1>
        <div class="admin-nav">
            <a href="dashboard.php">← Kembali ke Dashboard</a>
        </div>
    </div>
    
    <div class="form-container">
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="title">Judul Program *</label>
                <input type="text" id="title" name="title" required value="<?php echo htmlspecialchars($program['title']); ?>">
            </div>
            
            <div class="form-group">
                <label for="description">Deskripsi Singkat *</label>
                <input type="text" id="description" name="description" required value="<?php echo htmlspecialchars($program['description']); ?>">
            </div>
            
            <div class="form-group">
                <label for="icon">Icon (Emoji)</label>
                <input type="text" id="icon" name="icon" value="<?php echo htmlspecialchars($program['icon']); ?>">
            </div>
            
            <div class="form-group">
                <label for="details">Detail Program</label>
                <textarea id="details" name="details"><?php echo htmlspecialchars($program['details']); ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="published" <?php echo $program['status'] === 'published' ? 'selected' : ''; ?>>Terbit</option>
                    <option value="draft" <?php echo $program['status'] === 'draft' ? 'selected' : ''; ?>>Draft</option>
                </select>
            </div>
            
            <button type="submit" class="btn-submit">Update Program</button>
        </form>
    </div>
</body>
</html>
