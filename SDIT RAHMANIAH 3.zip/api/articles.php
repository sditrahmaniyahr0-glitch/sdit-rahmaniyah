<?php
require_once 'config.php';
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_SERVER['PATH_INFO'] ?? '', '/'));
$id = $path[0] ?? null;

// GET all articles or single article
if ($method === 'GET') {
    if ($id) {
        // Get single article by ID
        $stmt = $conn->prepare("SELECT a.*, u.full_name as author_name FROM articles a LEFT JOIN users u ON a.author_id = u.id WHERE a.id = ? AND a.status = 'published'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            errorResponse('Article not found', 404);
        }
        
        $article = $result->fetch_assoc();
        
        // Increment view count
        $updateStmt = $conn->prepare("UPDATE articles SET views = views + 1 WHERE id = ?");
        $updateStmt->bind_param("i", $id);
        $updateStmt->execute();
        
        jsonResponse($article);
    } else {
        // Get all published articles
        $category = $_GET['category'] ?? null;
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
        
        $query = "SELECT a.*, u.full_name as author_name FROM articles a LEFT JOIN users u ON a.author_id = u.id WHERE a.status = 'published'";
        
        if ($category) {
            $query .= " AND a.category = ?";
        }
        
        $query .= " ORDER BY a.created_at DESC LIMIT ? OFFSET ?";
        
        $stmt = $conn->prepare($query);
        
        if ($category) {
            $stmt->bind_param("sii", $category, $limit, $offset);
        } else {
            $stmt->bind_param("ii", $limit, $offset);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $articles = [];
        
        while ($row = $result->fetch_assoc()) {
            $articles[] = $row;
        }
        
        jsonResponse($articles);
    }
}

// POST - Create new article (requires authentication)
if ($method === 'POST') {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        errorResponse('Unauthorized', 401);
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['title']) || !isset($data['content'])) {
        errorResponse('Title and content are required');
    }
    
    $title = $data['title'];
    $content = $data['content'];
    $excerpt = $data['excerpt'] ?? substr(strip_tags($content), 0, 200) . '...';
    $image = $data['image'] ?? null;
    $category = $data['category'] ?? 'Kegiatan';
    $author_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("INSERT INTO articles (title, content, excerpt, image, category, author_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", $title, $content, $excerpt, $image, $category, $author_id);
    
    if ($stmt->execute()) {
        jsonResponse(['id' => $conn->insert_id, 'message' => 'Article created successfully'], 201);
    } else {
        errorResponse('Failed to create article');
    }
}

// PUT - Update article (requires authentication)
if ($method === 'PUT') {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        errorResponse('Unauthorized', 401);
    }
    
    if (!$id) {
        errorResponse('Article ID is required');
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    $title = $data['title'] ?? null;
    $content = $data['content'] ?? null;
    $excerpt = $data['excerpt'] ?? null;
    $image = $data['image'] ?? null;
    $category = $data['category'] ?? null;
    $status = $data['status'] ?? null;
    
    $query = "UPDATE articles SET ";
    $params = [];
    $types = "";
    
    if ($title) {
        $query .= "title = ?, ";
        $params[] = $title;
        $types .= "s";
    }
    if ($content) {
        $query .= "content = ?, ";
        $params[] = $content;
        $types .= "s";
    }
    if ($excerpt) {
        $query .= "excerpt = ?, ";
        $params[] = $excerpt;
        $types .= "s";
    }
    if ($image) {
        $query .= "image = ?, ";
        $params[] = $image;
        $types .= "s";
    }
    if ($category) {
        $query .= "category = ?, ";
        $params[] = $category;
        $types .= "s";
    }
    if ($status) {
        $query .= "status = ?, ";
        $params[] = $status;
        $types .= "s";
    }
    
    $query = rtrim($query, ", ");
    $query .= " WHERE id = ?";
    $params[] = $id;
    $types .= "i";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    
    if ($stmt->execute()) {
        jsonResponse(['message' => 'Article updated successfully']);
    } else {
        errorResponse('Failed to update article');
    }
}

// DELETE - Delete article (requires authentication)
if ($method === 'DELETE') {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        errorResponse('Unauthorized', 401);
    }
    
    if (!$id) {
        errorResponse('Article ID is required');
    }
    
    $stmt = $conn->prepare("DELETE FROM articles WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        jsonResponse(['message' => 'Article deleted successfully']);
    } else {
        errorResponse('Failed to delete article');
    }
}
?>
