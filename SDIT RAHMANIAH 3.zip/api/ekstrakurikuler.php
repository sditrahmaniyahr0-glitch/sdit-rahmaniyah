<?php
require_once 'config.php';
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_SERVER['PATH_INFO'] ?? '', '/'));
$id = $path[0] ?? null;

if ($method === 'GET') {
    if ($id) {
        $stmt = $conn->prepare("SELECT * FROM ekstrakurikuler WHERE id = ? AND status = 'published'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            errorResponse('Ekstrakurikuler not found', 404);
        }
        
        jsonResponse($result->fetch_assoc());
    } else {
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
        
        $query = "SELECT * FROM ekstrakurikuler WHERE status = 'published' ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $limit, $offset);
        $stmt->execute();
        $result = $stmt->get_result();
        $ekstrakurikuler = [];
        
        while ($row = $result->fetch_assoc()) {
            $ekstrakurikuler[] = $row;
        }
        
        jsonResponse($ekstrakurikuler);
    }
}

if ($method === 'POST') {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        errorResponse('Unauthorized', 401);
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['name']) || !isset($data['description'])) {
        errorResponse('Name and description are required');
    }
    
    $name = $data['name'];
    $description = $data['description'];
    $image = $data['image'] ?? null;
    $schedule = $data['schedule'] ?? null;
    $age_range = $data['age_range'] ?? null;
    $instructor = $data['instructor'] ?? null;
    $status = $data['status'] ?? 'published';
    
    $stmt = $conn->prepare("INSERT INTO ekstrakurikuler (name, description, image, schedule, age_range, instructor, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $description, $image, $schedule, $age_range, $instructor, $status);
    
    if ($stmt->execute()) {
        jsonResponse(['id' => $conn->insert_id, 'message' => 'Ekstrakurikuler created successfully'], 201);
    } else {
        errorResponse('Failed to create ekstrakurikuler');
    }
}

if ($method === 'PUT') {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        errorResponse('Unauthorized', 401);
    }
    
    if (!$id) {
        errorResponse('ID is required');
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    $query = "UPDATE ekstrakurikuler SET ";
    $params = [];
    $types = "";
    
    if (isset($data['name'])) {
        $query .= "name = ?, ";
        $params[] = $data['name'];
        $types .= "s";
    }
    if (isset($data['description'])) {
        $query .= "description = ?, ";
        $params[] = $data['description'];
        $types .= "s";
    }
    if (isset($data['image'])) {
        $query .= "image = ?, ";
        $params[] = $data['image'];
        $types .= "s";
    }
    if (isset($data['schedule'])) {
        $query .= "schedule = ?, ";
        $params[] = $data['schedule'];
        $types .= "s";
    }
    if (isset($data['age_range'])) {
        $query .= "age_range = ?, ";
        $params[] = $data['age_range'];
        $types .= "s";
    }
    if (isset($data['instructor'])) {
        $query .= "instructor = ?, ";
        $params[] = $data['instructor'];
        $types .= "s";
    }
    if (isset($data['status'])) {
        $query .= "status = ?, ";
        $params[] = $data['status'];
        $types .= "s";
    }
    
    $query = rtrim($query, ", ");
    $query .= " WHERE id = ?";
    $params[] = $id;
    $types .= "i";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    
    if ($stmt->execute()) {
        jsonResponse(['message' => 'Ekstrakurikuler updated successfully']);
    } else {
        errorResponse('Failed to update ekstrakurikuler');
    }
}

if ($method === 'DELETE') {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        errorResponse('Unauthorized', 401);
    }
    
    if (!$id) {
        errorResponse('ID is required');
    }
    
    $stmt = $conn->prepare("DELETE FROM ekstrakurikuler WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        jsonResponse(['message' => 'Ekstrakurikuler deleted successfully']);
    } else {
        errorResponse('Failed to delete ekstrakurikuler');
    }
}
?>
