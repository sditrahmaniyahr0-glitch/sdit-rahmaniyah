<?php
require_once 'config.php';
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_SERVER['PATH_INFO'] ?? '', '/'));
$id = $path[0] ?? null;

if ($method === 'GET') {
    if ($id) {
        $stmt = $conn->prepare("SELECT * FROM programs WHERE id = ? AND status = 'published'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            errorResponse('Program not found', 404);
        }
        
        jsonResponse($result->fetch_assoc());
    } else {
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
        
        $query = "SELECT * FROM programs WHERE status = 'published' ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $limit, $offset);
        $stmt->execute();
        $result = $stmt->get_result();
        $programs = [];
        
        while ($row = $result->fetch_assoc()) {
            $programs[] = $row;
        }
        
        jsonResponse($programs);
    }
}

if ($method === 'POST') {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        errorResponse('Unauthorized', 401);
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['title']) || !isset($data['description'])) {
        errorResponse('Title and description are required');
    }
    
    $title = $data['title'];
    $description = $data['description'];
    $icon = $data['icon'] ?? null;
    $details = $data['details'] ?? null;
    $status = $data['status'] ?? 'published';
    
    $stmt = $conn->prepare("INSERT INTO programs (title, description, icon, details, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $title, $description, $icon, $details, $status);
    
    if ($stmt->execute()) {
        jsonResponse(['id' => $conn->insert_id, 'message' => 'Program created successfully'], 201);
    } else {
        errorResponse('Failed to create program');
    }
}

if ($method === 'PUT') {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        errorResponse('Unauthorized', 401);
    }
    
    if (!$id) {
        errorResponse('ID is required');
    }
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    $query = "UPDATE programs SET ";
    $params = [];
    $types = "";
    
    if (isset($data['title'])) {
        $query .= "title = ?, ";
        $params[] = $data['title'];
        $types .= "s";
    }
    if (isset($data['description'])) {
        $query .= "description = ?, ";
        $params[] = $data['description'];
        $types .= "s";
    }
    if (isset($data['icon'])) {
        $query .= "icon = ?, ";
        $params[] = $data['icon'];
        $types .= "s";
    }
    if (isset($data['details'])) {
        $query .= "details = ?, ";
        $params[] = $data['details'];
        $types .= "s";
    }
    if (isset($data['status'])) {
        $query .= "status = ?, ";
        $params[] = $data['status'];
        $types .= "s";
    }
    
    $query = rtrim($query, ", ");
    $query .= " WHERE id = ?";
    $params[] = $id;
    $types .= "i";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    
    if ($stmt->execute()) {
        jsonResponse(['message' => 'Program updated successfully']);
    } else {
        errorResponse('Failed to update program');
    }
}

if ($method === 'DELETE') {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        errorResponse('Unauthorized', 401);
    }
    
    if (!$id) {
        errorResponse('ID is required');
    }
    
    $stmt = $conn->prepare("DELETE FROM programs WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        jsonResponse(['message' => 'Program deleted successfully']);
    } else {
        errorResponse('Failed to delete program');
    }
}
?>
