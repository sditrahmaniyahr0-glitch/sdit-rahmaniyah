-- Database Schema for SDIT Rahmaniyah Articles

CREATE DATABASE IF NOT EXISTS sdit_rahmaniyah;
USE sdit_rahmaniyah;

-- Users table for admin authentication
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'editor') DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Articles table
CREATE TABLE IF NOT EXISTS articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    excerpt VARCHAR(500),
    image VARCHAR(255),
    category ENUM('Kegiatan', 'Prestasi', 'Pembelajaran', 'Pengumuman', 'Profil') DEFAULT 'Kegiatan',
    author_id INT,
    status ENUM('draft', 'published') DEFAULT 'published',
    views INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Insert default admin user (password: admin123)
-- Password hashed with password_hash()
INSERT INTO users (username, password, email, full_name, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@sditrahmaniyah.sch.id', 'Administrator', 'admin');

-- Insert sample articles
INSERT INTO articles (title, content, excerpt, image, category, status) VALUES
('Upacara Bendera HUT RI ke-73', 'SDIT Rahmaniyah memperingati Hari Kemerdekaan Indonesia ke-73 dengan upacara bendera yang khidmat diikuti seluruh siswa dan guru. Upacara dimulai pukul 07.00 WIB dengan petugas upacara dari siswa kelas 6. Bapak/Ibu Guru memberikan amanat tentang makna kemerdekaan dan pentingnya menjaga persatuan.', 'SDIT Rahmaniyah memperingati Hari Kemerdekaan Indonesia ke-73 dengan upacara bendera yang khidmat.', 'assets/Artikel/Upacara Bendera HUT RI ke-73.jfif', 'Kegiatan', 'published'),
('Future Leader Kelas 6', 'Program pembinaan kepemimpinan untuk siswa kelas 6 sebagai persiapan menjadi generasi pemimpin masa depan yang berkarakter. Program ini mencakup pelatihan public speaking, manajemen waktu, kerja tim, dan nilai-nilai kepemimpinan Islami.', 'Program pembinaan kepemimpinan untuk siswa kelas 6 sebagai persiapan menjadi generasi pemimpin masa depan.', 'assets/Artikel/future leader kelas 6.jpeg', 'Prestasi', 'published'),
('Kuota SPMB PPDB Telah Habis', 'Terima kasih atas kepercayaan orang tua yang telah mendaftarkan putra-putrinya. Kuota PPDB tahun ajaran 2027/2028 telah terpenuh. Untuk informasi lebih lanjut, silakan hubungi admin sekolah.', 'Terima kasih atas kepercayaan orang tua. Kuota PPDB tahun ajaran 2027/2028 telah terpenuh.', 'assets/Artikel/kuota spmb habis.jpeg', 'Pengumuman', 'published'),
('SDIT Rahmaniyah Depok', 'Mengenal lebih dekat SDIT Rahmaniyah Depok, sekolah Islam terpadu yang berkomitmen mencetak generasi cerdas dan berakhlak mulia. Berdiri sejak 2003, SDIT Rahmaniyah telah melayani ratusan siswa dengan berbagai prestasi di tingkat daerah dan nasional.', 'Mengenal lebih dekat SDIT Rahmaniyah Depok, sekolah Islam terpadu yang berkomitmen mencetak generasi cerdas dan berakhlak mulia.', 'assets/Artikel/sdit rahmaniyah depok.jpg', 'Profil', 'published'),
('Turut Berduka Cita Gempa Bumi', 'SDIT Rahmaniyah menggalang dana dan doa untuk korban gempa bumi. Siswa belajar empati dan kepedulian terhadap sesama melalui program penggalangan dana yang dilaksanakan selama satu minggu.', 'SDIT Rahmaniyah menggalang dana dan doa untuk korban gempa bumi. Siswa belajar empati dan kepedulian.', 'assets/Artikel/turut berduka cita gempa bumi.jpeg', 'Kegiatan', 'published');

-- Ekstrakurikuler table
CREATE TABLE IF NOT EXISTS ekstrakurikuler (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    image VARCHAR(255),
    schedule VARCHAR(255),
    age_range VARCHAR(100),
    instructor VARCHAR(100),
    status ENUM('draft', 'published') DEFAULT 'published',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert sample ekstrakurikuler
INSERT INTO ekstrakurikuler (name, description, image, schedule, age_range, instructor, status) VALUES
('Futsal', 'Mengembangkan kemampuan olahraga dan kerja tim melalui permainan futsal yang terstruktur.', 'assets/Artikel/futsal.jpg', 'Senin & Kamis, 15:00 - 16:30', 'Kelas 1-6', 'Coach Budi', 'published'),
('Basket', 'Pelatihan basket fundamental untuk meningkatkan koordinasi dan kebugaran fisik.', 'assets/Artikel/basket.jpg', 'Selasa & Jumat, 15:00 - 16:30', 'Kelas 3-6', 'Coach Andi', 'published'),
('Pramuka', 'Kegiatan kepramukaan untuk membentuk karakter mandiri dan disiplin.', 'assets/Artikel/pramuka.jpg', 'Sabtu, 07:00 - 10:00', 'Kelas 1-6', 'Kak Rina', 'published'),
('Seni Tari', 'Belajar berbagai tari tradisional Indonesia untuk melestarikan budaya.', 'assets/Artikel/tari.jpg', 'Rabu, 14:00 - 15:30', 'Kelas 1-6', 'Bu Sari', 'published'),
('Robotik', 'Pengenalan dasar robotik dan coding untuk mengembangkan logika berpikir.', 'assets/Artikel/robotik.jpg', 'Kamis, 14:00 - 15:30', 'Kelas 4-6', 'Pak Dedi', 'published'),
('Bahasa Arab', 'Pembelajaran bahasa Arab dasar untuk kemampuan membaca dan berkomunikasi.', 'assets/Artikel/arab.jpg', 'Senin & Rabu, 14:00 - 15:00', 'Kelas 1-6', 'Ust. Ahmad', 'published'),
('Kaligrafi', 'Seni tulis Arab untuk mengasah kreativitas dan ketelitian.', 'assets/Artikel/kaligrafi.jpg', 'Selasa, 14:00 - 15:30', 'Kelas 2-6', 'Bu Fatimah', 'published'),
('Paduan Suara', 'Latihan vokal dan harmonisasi untuk pengembangan bakat musik.', 'assets/Artikel/paduan_suara.jpg', 'Jumat, 14:00 - 15:30', 'Kelas 1-6', 'Bu Maya', 'published');

-- Programs table
CREATE TABLE IF NOT EXISTS programs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    icon VARCHAR(50),
    details TEXT,
    status ENUM('draft', 'published') DEFAULT 'published',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert sample programs
INSERT INTO programs (title, description, icon, details, status) VALUES
('Tahfidz & Tahsin Metode Ummi', 'Program hafalan Al-Qur\'an dengan metode Ummi yang terbukti efektif dan mudah diikuti.', '📖', 'Target hafalan minimal 3 juz untuk kelas 6. Pembelajaran dilakukan setiap hari dengan bimbingan guru tahfidz bersertifikat. Evaluasi bulanan untuk monitoring progres hafalan.', 'published'),
('Akademik Berprestasi', 'Kurikulum nasional yang diperkaya dengan materi tambahan untuk keunggulan akademik.', '🎓', 'Fokus pada matematika, sains, dan bahasa. Program remedial dan pengayaan untuk siswa yang membutuhkan. Persiapan olimpiade sains dan matematika.', 'published'),
('Character Building Islami', 'Pembentukan karakter Islami melalui pembiasaan dan teladan guru.', '🕌', 'Program adab dan akhlak sehari-hari. Pembiasaan sholat dhuha dan dzuhur berjamaah. Pembelajaran hadits dan kisah para nabi.', 'published'),
('Bahasa & Literasi', 'Penguasaan bahasa Indonesia, Inggris, dan Arab serta kegemaran membaca.', '📚', 'Program literasi 15 menit sebelum KBM. English corner untuk praktik bahasa Inggris. Kompetisi bercerita dan debat.', 'published'),
('Sains, Teknologi & Digital Learning', 'Pembelajaran sains modern dengan dukungan teknologi dan digital learning.', '💻', 'Laboratorium sains dan komputer lengkap. Pembelajaran coding dasar untuk kelas 4-6. Penggunaan tablet dan aplikasi edukatif.', 'published'),
('Leadership', 'Pengembangan kepemimpinan dan kemandirian siswa.', '👑', 'Program Future Leader untuk kelas 6. Tugas ketua OSIS dan ketua kelas bergantian. Pelatihan public speaking dan manajemen waktu.', 'published'),
('Ekstrakurikuler & Pengembangan Bakat', 'Berbagai kegiatan ekstrakurikuler untuk mengembangkan potensi siswa.', '⚽', '8 pilihan ekstrakurikuler: Futsal, Basket, Pramuka, Seni Tari, Robotik, Bahasa Arab, Kaligrafi, dan Paduan Suara. Kompetisi antar sekolah.', 'published'),
('Parenting & Kolaborasi Orang Tua', 'Program kolaborasi sekolah dan orang tua untuk pendidikan yang optimal.', '🤝', 'Kelas parenting bulanan. Komunikasi rutin via WhatsApp grup. Program home visit untuk siswa yang membutuhkan perhatian khusus.', 'published');
