
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SDIT Rahmaniyah — Mendidik Generasi Bercahaya</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="ppdb-popup-overlay" id="ppdbPopup">
  <div class="ppdb-popup" role="dialog" aria-modal="true" aria-labelledby="ppdbTitle">
    <button class="ppdb-close" id="ppdbClose" aria-label="Tutup pengumuman">✕</button>
    <!-- GANTI dengan poster/foto PPDB asli: <img src="poster-ppdb.jpg" alt="Poster PPDB SDIT Rahmaniyah"> -->
    <div class="ppdb-banner">
      <img class="logo-mark" src="assets/logo-sdit-rahmaniyah.png" alt="Logo SDIT Rahmaniyah" style="width: 80px; height: auto;">
      <span>Poster / Foto PPDB SDIT Rahmaniyah</span>
    </div>
    <div class="ppdb-content">
      <span class="ppdb-badge">📢 Pengumuman</span>
      <h3 id="ppdbTitle">PPDB Tahun Ajaran 2027/2028 Telah Dibuka!</h3>
      <p>Daftarkan putra-putri Anda sekarang dan dapatkan berbagai keuntungan khusus untuk pendaftar gelombang pertama.</p>
      <div class="ppdb-actions">
        <a href="#daftar" class="btn btn-primary" id="ppdbCta">Daftar Sekarang</a>
        <button class="ppdb-later" id="ppdbLater">Nanti Saja</button>
      </div>
    </div>
  </div>
</div>

<header id="siteHeader">
  <nav class="nav">
    <a href="index.html" class="logo"><img class="logo-mark" src="assets/logo-sdit-rahmaniyah.png" alt="Logo SDIT Rahmaniyah"> SDIT Rahmaniyah</a>
    <div class="nav-links">
      <a href="about.html">About Us</a>
      <a href="program.html">Program Unggulan</a>
      <a href="ekstrakurikuler.html">Ekstrakurikuler</a>
      <a href="artikel.php">Artikel</a>
      <a href="kontak.html">Kontak</a>
    </div>
    <div class="nav-right">
      <div class="nav-cta">
        <a href="login.html" class="btn btn-outline-navy">Login</a>
        <a href="daftar-ppdb.html" class="btn btn-primary">Daftar PPDB</a>
      </div>
      <button class="menu-toggle" id="menuToggle" aria-label="Buka menu">
        <span></span><span></span><span></span>
      </button>
    </div>
  </nav>
</header>

<section class="hero">
  <div class="hero-inner">
    <div class="hero-copy">
      <span class="eyebrow">SDIT Rahmaniyah</span>
      <h1>Mendidik Generasi <span>Bercahaya</span></h1>
      <p>SDIT Rahmaniyah memadukan pendidikan Al-Qur'an, akademik, dan pembentukan karakter Islami untuk menumbuhkan generasi yang cerdas, berakhlak mulia, dan bercahaya bagi lingkungannya.</p>
      <div class="hero-actions">
        <a href="daftar-ppdb.html" class="btn btn-primary">Daftar PPDB</a>
        <a href="program.html" class="btn btn-ghost">Program Unggulan →</a>
      </div>
      <div class="hero-stats">
        <div><strong>20+</strong><span>Tahun Berdiri</span></div>
        <div><strong>A</strong><span>Akreditasi Sekolah</span></div>
        <div><strong>600+</strong><span>Siswa Aktif</span></div>
      </div>
    </div>
    <div class="hero-visual" aria-hidden="true">
      <!-- GANTI src di bawah ini dengan foto asli sekolah -->
      <img class="hero-photo" src="https://placehold.co/900x700/14213D/1E2E52?text=Foto+SDIT+Rahmaniyah" alt="Foto SDIT Rahmaniyah">
      <div class="hero-photo-overlay"></div>
      <img class="logo-mark" src="assets/logo-sdit-rahmaniyah.png" alt="Logo SDIT Rahmaniyah" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: calc(90% - 32px); height: auto; z-index: 5;">
      <div class="rintik-layer" id="rintikLayer" style="z-index: 10;"></div>
      <div class="hero-visual-caption" style="bottom: 5px; left: 16px;"><span class="dot"></span> SDIT Rahmaniyah — Bercahaya</div>
    </div>
  </div>
  <svg class="hero-wave" viewBox="0 0 1440 60" preserveAspectRatio="none">
    <path d="M0,32 C360,80 1080,-16 1440,32 L1440,60 L0,60 Z" fill="#F6F7FB"/>
  </svg>
</section>

<div class="marquee-strip" aria-hidden="true">
  <div class="marquee-track">
    <span class="marquee-item">Ramah dalam Mendidik <span class="sep">●</span> Amanah dalam Membimbing <span class="sep">●</span> Menginspirasi dalam Berkarya <span class="sep">●</span> Sekolah Ramah Anak <span class="sep">●</span></span>
    <span class="marquee-item">Ramah dalam Mendidik <span class="sep">●</span> Amanah dalam Membimbing <span class="sep">●</span> Menginspirasi dalam Berkarya <span class="sep">●</span> Sekolah Ramah Anak <span class="sep">●</span></span>
  </div>
</div>

<div class="trust">
  <div class="wrap">
    <span class="trust-label">Terakreditasi & diawasi oleh</span>
    <div class="trust-logos">
      <span>Kemendikbudristek</span><span>Kemenag</span><span>BAN-S/M</span><span>Yayasan Rahmaniyah</span>
    </div>
  </div>
</div>

<section id="about">
  <div class="wrap">
    <div class="about-grid">
      <div class="about-visual"><span>SDIT Rahmaniyah — Bercahaya</span></div>
      <div>
        <span class="eyebrow">About Us</span>
        <h2>Mengenal SDIT Rahmaniyah Lebih Dekat</h2>
        <p style="color:var(--ink-muted); margin-top:14px;">SDIT Rahmaniyah adalah sekolah dasar Islam terpadu yang berkomitmen membentuk siswa yang seimbang secara akademik, spiritual, dan sosial, melalui pembelajaran yang ramah, amanah, dan menginspirasi.</p>
        <a href="#" class="btn btn-outline-navy" style="margin-top:22px;">Baca Selengkapnya →</a>
      </div>
    </div>

    <div class="ramah-head">
      <span class="eyebrow" style="justify-content:center;">Nilai Sekolah</span>
      <h2>RAMAH — Lima Nilai SDIT Rahmaniyah</h2>
      <p style="color:var(--ink-muted); margin-top:10px;">Arahkan kursor atau sentuh setiap kartu untuk melihat maknanya.</p>
    </div>
    <div class="ramah-grid">
      <div class="ramah-card" tabindex="0">
        <div class="ramah-inner">
          <div class="ramah-front"><span class="letter">R</span><span class="word">Ramah</span><span class="hint">Sentuh untuk lihat makna</span></div>
          <div class="ramah-back"><span class="back-letter">R — Ramah</span><p>Membangun lingkungan sekolah yang penuh kepedulian dan saling menghargai.</p></div>
        </div>
      </div>
      <div class="ramah-card" tabindex="0">
        <div class="ramah-inner">
          <div class="ramah-front"><span class="letter">A</span><span class="word">Amanah</span><span class="hint">Sentuh untuk lihat makna</span></div>
          <div class="ramah-back"><span class="back-letter">A — Amanah</span><p>Mendidik dengan penuh tanggung jawab, kejujuran, dan kepercayaan.</p></div>
        </div>
      </div>
      <div class="ramah-card" tabindex="0">
        <div class="ramah-inner">
          <div class="ramah-front"><span class="letter">M</span><span class="word">Manfaat</span><span class="hint">Sentuh untuk lihat makna</span></div>
          <div class="ramah-back"><span class="back-letter">M — Manfaat</span><p>Memberikan ilmu dan pengalaman yang bermanfaat bagi kehidupan.</p></div>
        </div>
      </div>
      <div class="ramah-card" tabindex="0">
        <div class="ramah-inner">
          <div class="ramah-front"><span class="letter">A</span><span class="word">[Nilai Positif]</span><span class="hint">Sentuh untuk lihat makna</span></div>
          <div class="ramah-back"><span class="back-letter">A — [Nilai Positif]</span><p>Isi dengan nilai pendidikan positif yang sesuai dengan karakter sekolah.</p></div>
        </div>
      </div>
      <div class="ramah-card" tabindex="0">
        <div class="ramah-inner">
          <div class="ramah-front"><span class="letter">H</span><span class="word">Harmonis</span><span class="hint">Sentuh untuk lihat makna</span></div>
          <div class="ramah-back"><span class="back-letter">H — Harmonis</span><p>Menciptakan hubungan yang harmonis antara siswa, guru, orang tua, dan lingkungan.</p></div>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="program" style="background:var(--paper);">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Program Unggulan</span>
      <h2>Delapan Pilar Pendidikan SDIT Rahmaniyah</h2>
      <p>Program yang dirancang menyeluruh untuk mendampingi tumbuh kembang siswa dari sisi spiritual, akademik, hingga karakter.</p>
    </div>
    <div class="program-grid" id="programGrid">
      <div class="program-card">
        <div class="program-photo">Foto Tahfidz &amp; Tahsin</div>
        <div class="program-body"><h3>Tahfidz &amp; Tahsin Al-Qur'an Metode Ummi</h3><p>Pembinaan bacaan dan hafalan Al-Qur'an secara bertahap dan terukur.</p></div>
      </div>
      <div class="program-card">
        <div class="program-photo">Foto Akademik</div>
        <div class="program-body"><h3>Akademik Berprestasi</h3><p>Kurikulum akademik yang kuat untuk membekali siswa siap berprestasi.</p></div>
      </div>
      <div class="program-card">
        <div class="program-photo">Foto Character Building</div>
        <div class="program-body"><h3>Character Building Islami</h3><p>Pembentukan akhlak dan kepribadian berlandaskan nilai-nilai Islam.</p></div>
      </div>
      <div class="program-card">
        <div class="program-photo">Foto Bahasa &amp; Literasi</div>
        <div class="program-body"><h3>Bahasa &amp; Literasi</h3><p>Penguatan kemampuan berbahasa dan minat baca sejak usia dini.</p></div>
      </div>
      <div class="program-card">
        <div class="program-photo">Foto Digital Learning</div>
        <div class="program-body"><h3>Sains, Teknologi &amp; Digital Learning</h3><p>Pengenalan sains dan teknologi melalui pembelajaran yang interaktif.</p></div>
      </div>
      <div class="program-card">
        <div class="program-photo">Foto Leadership</div>
        <div class="program-body"><h3>Leadership</h3><p>Melatih jiwa kepemimpinan dan kemandirian siswa sejak dini.</p></div>
      </div>
      <div class="program-card">
        <div class="program-photo">Foto Ekstrakurikuler</div>
        <div class="program-body"><h3>Ekstrakurikuler &amp; Pengembangan Bakat</h3><p>Wadah eksplorasi minat dan bakat siswa di luar kegiatan akademik.</p></div>
      </div>
      <div class="program-card">
        <div class="program-photo">Foto Parenting</div>
        <div class="program-body"><h3>Parenting &amp; Kolaborasi Orang Tua</h3><p>Sinergi sekolah dan orang tua dalam mendukung tumbuh kembang anak.</p></div>
      </div>
    </div>
    <div class="article-foot">
      <a href="program.html" class="btn btn-outline-navy">Lihat Program Unggulan</a>
    </div>
  </div>
</section>

<section id="ekskul" class="ekskul">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Ekstrakurikuler</span>
      <h2>Ruang Berkembang di Luar Kelas</h2>
      <p>Beragam kegiatan ekstrakurikuler untuk menyalurkan minat dan bakat siswa.</p>
    </div>
    <div class="ekskul-grid">
      <div class="ekskul-tag"><div class="ekskul-photo">Foto Pramuka</div><span>Pramuka</span></div>
      <div class="ekskul-tag"><div class="ekskul-photo">Foto Futsal</div><span>Futsal</span></div>
      <div class="ekskul-tag"><div class="ekskul-photo">Foto Panahan</div><span>Panahan</span></div>
      <div class="ekskul-tag"><div class="ekskul-photo">Foto Robotik</div><span>Robotik</span></div>
      <div class="ekskul-tag"><div class="ekskul-photo">Foto Tilawah</div><span>Tilawah &amp; Nasyid</span></div>
      <div class="ekskul-tag"><div class="ekskul-photo">Foto Kaligrafi</div><span>Melukis &amp; Kaligrafi</span></div>
      <div class="ekskul-tag"><div class="ekskul-photo">Foto Renang</div><span>Renang</span></div>
      <div class="ekskul-tag"><div class="ekskul-photo">Foto English Club</div><span>English Club</span></div>
    </div>
    <div class="article-foot">
      <a href="ekstrakurikuler.html" class="btn btn-outline-navy">Lihat Selengkapnya</a>
    </div>
  </div>
</section>

<section id="artikel" style="background:var(--paper);">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Artikel Sekolah</span>
      <h2>Kabar &amp; Kegiatan Terbaru</h2>
      <p>Informasi seputar kegiatan, prestasi, dan momen belajar siswa SDIT Rahmaniyah.</p>
    </div>
    <div class="article-grid">
      <?php if (!empty($latest_articles)): ?>
        <?php foreach ($latest_articles as $article): ?>
          <article class="article-card">
            <div class="article-thumb" style="background-image: url('<?php echo htmlspecialchars($article['image'] ?: 'assets/Artikel/default.jpg'); ?>'); background-size: cover; background-position: center;"></div>
            <div class="article-body">
              <span class="article-tag"><?php echo htmlspecialchars($article['category']); ?></span>
              <h3><?php echo htmlspecialchars($article['title']); ?></h3>
              <p><?php echo htmlspecialchars($article['excerpt']); ?></p>
              <div class="article-meta">
                <span><?php echo date('d F Y', strtotime($article['created_at'])); ?></span>
                <a href="artikel-detail.php?id=<?php echo $article['id']; ?>">Baca Selengkapnya →</a>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
      <?php else: ?>
        <article class="article-card">
          <div class="article-thumb">�</div>
          <div class="article-body">
            <span class="article-tag">Informasi</span>
            <h3>Belum Ada Artikel</h3>
            <p>Artikel terbaru akan segera ditampilkan di sini.</p>
            <div class="article-meta"><span>-</span><a href="artikel.html">Lihat Semua Artikel →</a></div>
          </div>
        </article>
      <?php endif; ?>
    </div>
    <div class="article-foot">
      <a href="artikel.php" class="btn btn-outline-navy">Lihat Semua Artikel</a>
    </div>
  </div>
</section>

<section id="testimoni" class="testi">
  <div class="wrap">
    <div class="section-head center">
      <span class="eyebrow">Apa Kata Mereka</span>
      <h2>Cerita dari Keluarga Besar SDIT Rahmaniyah</h2>
    </div>

    <div class="testi-tabs">
      <button class="testi-tab-btn active" data-group="ortu">Orang Tua</button>
      <button class="testi-tab-btn" data-group="alumni">Alumni</button>
    </div>

    <div class="testi-slider">
      <div class="testi-group active" id="group-ortu">
        <div class="testi-track">
          <div class="testi-slides" data-slides="ortu">
            <div class="testi-slide">
              <div class="testi-card">
                <div class="testi-avatar">B</div>
                <p class="testi-quote">"Anak saya jadi lebih rajin membaca Al-Qur'an dan lebih percaya diri sejak bersekolah di sini."</p>
                <div class="testi-name">Bu Nurhayati</div>
                <div class="testi-role">Wali Murid Kelas 3</div>
              </div>
            </div>
            <div class="testi-slide">
              <div class="testi-card">
                <div class="testi-avatar">P</div>
                <p class="testi-quote">"Komunikasi sekolah dengan orang tua sangat baik, program parenting juga sangat membantu."</p>
                <div class="testi-name">Pak Fajar Ramadhan</div>
                <div class="testi-role">Wali Murid Kelas 5</div>
              </div>
            </div>
            <div class="testi-slide">
              <div class="testi-card">
                <div class="testi-avatar">S</div>
                <p class="testi-quote">"Gurunya sabar dan telaten, anak saya makin semangat berangkat sekolah setiap hari."</p>
                <div class="testi-name">Bu Siti Aisyah</div>
                <div class="testi-role">Wali Murid Kelas 1</div>
              </div>
            </div>
          </div>
        </div>
        <div class="testi-dots" data-dots="ortu"></div>
      </div>

      <div class="testi-group" id="group-alumni">
        <div class="testi-track">
          <div class="testi-slides" data-slides="alumni">
            <div class="testi-slide">
              <div class="testi-card">
                <div class="testi-avatar">D</div>
                <p class="testi-quote">"Bekal tahfidz dari SDIT Rahmaniyah sangat membantu saya beradaptasi di pesantren."</p>
                <div class="testi-name">Dzaky Ramadhan</div>
                <div class="testi-role">Alumni, kini siswa SMP</div>
              </div>
            </div>
            <div class="testi-slide">
              <div class="testi-card">
                <div class="testi-avatar">N</div>
                <p class="testi-quote">"Kebiasaan disiplin dan percaya diri yang saya dapat di sana masih terasa sampai sekarang."</p>
                <div class="testi-name">Naila Zahra</div>
                <div class="testi-role">Alumni, kini siswa SMP</div>
              </div>
            </div>
          </div>
        </div>
        <div class="testi-dots" data-dots="alumni"></div>
      </div>
    </div>
  </div>
</section>

<section id="daftar">
  <div class="cta">
    <h2>Siap Bergabung Sekolah Ramah Anak?</h2>
    <p>Daftarkan putra-putri Anda dan jadilah bagian dari generasi yang bercahaya.</p>
    <div class="cta-actions">
      <a href="kontak.html" class="btn btn-ghost">Hubungi Kami</a>
      <a href="daftar-ppdb.html" class="btn btn-primary">Daftar PPDB Sekarang</a>
    </div>
  </div>
</section>

<footer id="kontak">
  <div class="footer-grid">
    <div>
      <div class="logo" style="color:#fff;"><img class="logo-mark" src="assets/logo-sdit-rahmaniyah.png" alt="Logo SDIT Rahmaniyah"> SDIT Rahmaniyah</div>
      <p class="footer-desc">Sekolah Dasar Islam Terpadu yang mendidik generasi cerdas, berakhlak, dan bercahaya.</p>
    </div>
    <div>
      <h4>Tautan</h4>
      <ul>
        <li><a href="#about">About Us</a></li>
        <li><a href="#program">Program Unggulan</a></li>
        <li><a href="#ekskul">Ekstrakurikuler</a></li>
        <li><a href="artikel.php">Artikel</a></li>
        <li><a href="#login">Login</a></li>
      </ul>
    </div>
    <div>
      <h4>Program</h4>
      <ul>
        <li><a href="#program">Tahfidz &amp; Tahsin Metode Ummi</a></li>
        <li><a href="#program">Akademik Berprestasi</a></li>
        <li><a href="#program">Character Building Islami</a></li>
        <li><a href="#program">Bahasa &amp; Literasi</a></li>
        <li><a href="#program">Sains, Teknologi &amp; Digital Learning</a></li>
        <li><a href="#program">Leadership</a></li>
        <li><a href="#program">Ekstrakurikuler &amp; Pengembangan Bakat</a></li>
        <li><a href="#program">Parenting &amp; Kolaborasi Orang Tua</a></li>
      </ul>
    </div>
    <div>
      <h4>Kontak &amp; Lokasi</h4>
      <p style="font-size:14px; margin:0 0 4px;">Jl. Rahmaniyah Raya No. 10</p>
      <p style="font-size:14px; margin:0;">Depok, Jawa Barat</p>
      <a class="map-card" href="https://www.google.com/maps/search/?api=1&query=SDIT+Rahmaniyah+Depok" target="_blank" rel="noopener">
        <span class="pin">📍</span>
        <span class="txt"><strong>Lihat Lokasi</strong><span>Buka di Google Maps →</span></span>
      </a>
      <div class="social-row">
        <a href="https://facebook.com/rahmaniyahofficial" target="_blank" rel="noopener" aria-label="Facebook SDIT Rahmaniyah">
          <svg viewBox="0 0 24 24"><path d="M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06c0 5 3.66 9.15 8.44 9.94v-7.03H7.9v-2.91h2.54V9.85c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56v1.88h2.78l-.44 2.91h-2.34V22c4.78-.79 8.44-4.94 8.44-9.94Z"/></svg>
        </a>
        <a href="https://instagram.com/sditrahmaniyah/" target="_blank" rel="noopener" aria-label="Instagram SDIT Rahmaniyah">
          <svg viewBox="0 0 24 24"><path d="M12 2c2.72 0 3.06.01 4.12.06 1.06.05 1.79.22 2.43.47.66.26 1.22.6 1.77 1.15.5.5.86 1.08 1.15 1.77.25.64.42 1.37.47 2.43C21.99 8.94 22 9.28 22 12s-.01 3.06-.06 4.12c-.05 1.06-.22 1.79-.47 2.43a4.9 4.9 0 0 1-1.15 1.77 4.9 4.9 0 0 1-1.77 1.15c-.64.25-1.37.42-2.43.47C15.06 21.99 14.72 22 12 22s-3.06-.01-4.12-.06c-1.06-.05-1.79-.22-2.43-.47a4.9 4.9 0 0 1-1.77-1.15 4.9 4.9 0 0 1-1.15-1.77c-.25-.64-.42-1.37-.47-2.43C2.01 15.06 2 14.72 2 12s.01-3.06.06-4.12c.05-1.06.22-1.79.47-2.43.26-.66.6-1.22 1.15-1.77A4.9 4.9 0 0 1 5.45.53C6.09.28 6.82.11 7.88.06 8.94.01 9.28 0 12 0Zm0 5a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm0 8.2a3.2 3.2 0 1 1 0-6.4 3.2 3.2 0 0 1 0 6.4Zm5.4-8.4a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4Z" transform="translate(0 2)"/></svg>
        </a>
        <a href="https://youtube.com/@SDITRahmaniyahchannel" target="_blank" rel="noopener" aria-label="YouTube SDIT Rahmaniyah">
          <svg viewBox="0 0 24 24"><path d="M23.5 6.2s-.23-1.64-.94-2.36c-.9-.95-1.9-.95-2.36-1.01C16.87 2.5 12 2.5 12 2.5h-.01s-4.87 0-8.2.33c-.46.06-1.46.06-2.36 1.01-.71.72-.94 2.36-.94 2.36S.15 8.13.15 10.06v1.87c0 1.93.24 3.86.24 3.86s.23 1.64.94 2.36c.9.95 2.08.92 2.6 1.02 1.9.18 8.07.31 8.07.31s4.87-.01 8.2-.34c.46-.06 1.46-.06 2.36-1.01.71-.72.94-2.36.94-2.36s.24-1.93.24-3.86v-1.87c0-1.93-.24-3.86-.24-3.86ZM9.75 14.85V7.87l6.5 3.5-6.5 3.48Z"/></svg>
        </a>
        <a href="https://wa.me/6281234567890" target="_blank" rel="noopener" aria-label="WhatsApp SDIT Rahmaniyah">
          <svg viewBox="0 0 24 24"><path d="M17.47 14.38c-.29-.15-1.7-.84-1.97-.93-.26-.1-.46-.15-.65.15-.2.29-.75.93-.92 1.12-.17.2-.34.22-.63.08-.29-.15-1.22-.45-2.32-1.44-.86-.76-1.44-1.7-1.6-1.99-.17-.29-.02-.44.13-.59.13-.13.29-.34.44-.51.15-.17.2-.29.29-.49.1-.2.05-.37-.02-.51-.08-.15-.65-1.58-.9-2.16-.24-.57-.48-.5-.65-.5-.17-.01-.37-.01-.56-.01-.2 0-.51.07-.78.37-.26.29-1.02 1-1.02 2.43 0 1.43 1.05 2.82 1.19 3.01.15.2 2.06 3.15 5 4.42.7.3 1.24.48 1.67.61.7.22 1.34.19 1.84.11.56-.08 1.7-.7 1.94-1.37.24-.68.24-1.26.17-1.38-.07-.12-.26-.2-.55-.35ZM12.02 22h-.01a9.98 9.98 0 0 1-5.09-1.4l-.36-.22-3.79.99 1.01-3.7-.24-.38A9.94 9.94 0 0 1 2 12.06C2 6.51 6.5 2 12.02 2c2.67 0 5.18 1.04 7.07 2.93A9.93 9.93 0 0 1 22 12.07c0 5.55-4.5 10.06-9.98 9.93Zm8.5-18.44A11.9 11.9 0 0 0 12.02 0C5.4 0 .04 5.4.04 12.06c0 2.13.56 4.2 1.62 6.03L0 24l6.06-1.59a11.9 11.9 0 0 0 5.95 1.6h.01c6.62 0 12-5.4 12-12.06a12 12 0 0 0-3.5-8.4Z"/></svg>
        </a>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© 2026 SDIT Rahmaniyah.</span>
    <span>Bercahaya bersama SDIT Rahmaniyah</span>
  </div>
</footer>

<script src="js/script.js"></script>

</body>
</html>
