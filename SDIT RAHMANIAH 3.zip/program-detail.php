<?php
require_once 'api/config.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    header('Location: program.html');
    exit;
}

$stmt = $conn->prepare("SELECT * FROM programs WHERE id = ? AND status = 'published'");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: program.html');
    exit;
}

$program = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($program['title']); ?> — SDIT Rahmaniyah</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<header id="siteHeader">
  <nav class="nav">
    <a href="index.html" class="logo"><img class="logo-mark" src="assets/logo-sdit-rahmaniyah.png" alt="Logo SDIT Rahmaniyah"> SDIT Rahmaniyah</a>
    <div class="nav-links">
      <a href="about.html">About Us</a>
      <a href="program.html" class="active">Program Unggulan</a>
      <a href="ekstrakurikuler.html">Ekstrakurikuler</a>
      <a href="artikel.html">Artikel</a>
      <a href="kontak.html">Kontak</a>
    </div>
    <div class="nav-right">
      <div class="nav-cta">
        <a href="login.html" class="btn btn-outline-navy">Login</a>
        <a href="daftar-ppdb.html" class="btn btn-primary">Daftar PPDB</a>
      </div>
      <button class="menu-toggle" id="menuToggle" aria-label="Buka menu">
        <span></span><span></span><span></span>
      </button>
    </div>
  </nav>
</header>

<section class="hero" style="background: linear-gradient(1100px 550px at 85% -10%, #2563EB 0%, var(--navy) 55%, var(--navy) 100%); padding: 120px 24px 80px;">
  <div class="wrap">
    <div class="hero-copy" style="max-width: 800px;">
      <span class="eyebrow">Program Unggulan</span>
      <h1><?php echo htmlspecialchars($program['title']); ?></h1>
      <p style="color: rgba(255,255,255,0.85); max-width: 600px; font-size: 18px;">
        <?php echo htmlspecialchars($program['description']); ?>
      </p>
    </div>
  </div>
</section>

<section style="background: var(--paper); padding: 80px 24px;">
  <div class="wrap">
    <div style="max-width: 900px; margin: 0 auto;">
      <div style="background: var(--bg); padding: 48px; border-radius: 24px; border: 1px solid var(--line); text-align: center; margin-bottom: 40px;">
        <div style="font-size: 80px; margin-bottom: 16px;"><?php echo htmlspecialchars($program['icon'] ?? '📖'); ?></div>
        <h2 style="font-size: 32px; margin-bottom: 16px;"><?php echo htmlspecialchars($program['title']); ?></h2>
        <p style="color: var(--ink-muted); font-size: 18px; max-width: 600px; margin: 0 auto;">
          <?php echo htmlspecialchars($program['description']); ?>
        </p>
      </div>
      
      <?php if ($program['details']): ?>
      <div style="line-height: 1.8; font-size: 17px; color: var(--ink);">
        <?php echo nl2br(htmlspecialchars($program['details'])); ?>
      </div>
      <?php endif; ?>
      
      <div style="margin-top: 48px; padding-top: 32px; border-top: 1px solid var(--line);">
        <a href="program.html" class="btn btn-ghost">← Kembali ke Program Unggulan</a>
      </div>
    </div>
  </div>
</section>

<footer id="kontak">
  <div class="footer-grid">
    <div>
      <div class="logo" style="color:#fff;"><img class="logo-mark" src="assets/logo-sdit-rahmaniyah.png" alt="Logo SDIT Rahmaniyah"> SDIT Rahmaniyah</div>
      <p class="footer-desc">Sekolah Dasar Islam Terpadu yang mendidik generasi cerdas, berakhlak, dan bercahaya.</p>
    </div>
    <div>
      <h4>Tautan</h4>
      <ul>
        <li><a href="about.html">About Us</a></li>
        <li><a href="program.html">Program Unggulan</a></li>
        <li><a href="ekstrakurikuler.html">Ekstrakurikuler</a></li>
        <li><a href="artikel.html">Artikel</a></li>
        <li><a href="kontak.html">Kontak</a></li>
      </ul>
    </div>
    <div>
      <h4>Program</h4>
      <ul>
        <li><a href="program.html">Tahfidz &amp; Tahsin Metode Ummi</a></li>
        <li><a href="program.html">Akademik Berprestasi</a></li>
        <li><a href="program.html">Character Building Islami</a></li>
        <li><a href="program.html">Bahasa &amp; Literasi</a></li>
        <li><a href="program.html">Sains, Teknologi &amp; Digital Learning</a></li>
        <li><a href="program.html">Leadership</a></li>
        <li><a href="program.html">Ekstrakurikuler &amp; Pengembangan Bakat</a></li>
        <li><a href="program.html">Parenting &amp; Kolaborasi Orang Tua</a></li>
      </ul>
    </div>
    <div>
      <h4>Kontak &amp; Lokasi</h4>
      <p style="font-size:14px; margin:0 0 4px;">Jl. Rahmaniyah Raya No. 10</p>
      <p style="font-size:14px; margin:0;">Depok, Jawa Barat</p>
      <a class="map-card" href="https://www.google.com/maps/search/?api=1&query=SDIT+Rahmaniyah+Depok" target="_blank" rel="noopener">
        <span class="pin">📍</span>
        <span class="txt"><strong>Lihat Lokasi</strong><span>Buka di Google Maps →</span></span>
      </a>
      <div class="social-row">
        <a href="https://facebook.com/rahmaniyahofficial" target="_blank" rel="noopener" aria-label="Facebook SDIT Rahmaniyah">
          <svg viewBox="0 0 24 24"><path d="M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06c0 5 3.66 9.15 8.44 9.94v-7.03H7.9v-2.91h2.54V9.85c0-2.5 1.49-3.89 3.77-3.89 1.09 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56v1.88h2.78l-.44 2.91h-2.34V22c4.78-.79 8.44-4.94 8.44-9.94Z"/></svg>
        </a>
        <a href="https://instagram.com/sditrahmaniyah/" target="_blank" rel="noopener" aria-label="Instagram SDIT Rahmaniyah">
          <svg viewBox="0 0 24 24"><path d="M12 2c2.72 0 3.06.01 4.12.06 1.06.05 1.79.22 2.43.47.66.26 1.22.6 1.77 1.15.5.5.86 1.08 1.15 1.77.25.64.42 1.37.47 2.43C21.99 8.94 22 9.28 22 12s-.01 3.06-.06 4.12c-.05 1.06-.22 1.79-.47 2.43a4.9 4.9 0 0 1-1.15 1.77 4.9 4.9 0 0 1-1.77 1.15c-.64.25-1.37.42-2.43.47C15.06 21.99 14.72 22 12 22s-3.06-.01-4.12-.06c-1.06-.05-1.79-.22-2.43-.47a4.9 4.9 0 0 1-1.77-1.15 4.9 4.9 0 0 1-1.15-1.77c-.25-.64-.42-1.37-.47-2.43C2.01 15.06 2 14.72 2 12s.01-3.06.06-4.12c.05-1.06.22-1.79.47-2.43.26-.66.6-1.22 1.15-1.77A4.9 4.9 0 0 0 5.45.53C6.09.28 6.82.11 7.88.06 8.94.01 9.28 0 12 0Zm0 5a5 5 0 1 0 0 10 5 5 0 0 0 0-10Zm0 8.2a3.2 3.2 0 1 1 0-6.4 3.2 3.2 0 0 1 0 6.4Zm5.4-8.4a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4Z" transform="translate(0 2)"/></svg>
        </a>
        <a href="https://youtube.com/@SDITRahmaniyahchannel" target="_blank" rel="noopener" aria-label="YouTube SDIT Rahmaniyah">
          <svg viewBox="0 0 24 24"><path d="M23.5 6.2s-.23-1.64-.94-2.36c-.9-.95-1.9-.95-2.36-1.01C16.87 2.5 12 2.5 12 2.5h-.01s-4.87 0-8.2.33c-.46.06-1.46.06-2.36 1.01-.71.72-.94 2.36-.94 2.36S.15 8.13.15 10.06v1.87c0 1.93.24 3.86.24 3.86s.23 1.64.94 2.36c.9.95 2.08.92 2.6 1.02 1.9.18 8.07.31 8.07.31s4.87-.01 8.2-.34c.46-.06 1.46-.06 2.36-1.01.71-.72.94-2.36.94-2.36s.24-1.93.24-3.86v-1.87c0-1.93-.24-3.86-.24-3.86ZM9.75 14.85V7.87l6.5 3.5-6.5 3.48Z"/></svg>
        </a>
        <a href="https://wa.me/6281234567890" target="_blank" rel="noopener" aria-label="WhatsApp SDIT Rahmaniyah">
          <svg viewBox="0 0 24 24"><path d="M17.47 14.38c-.29-.15-1.7-.84-1.97-.93-.26-.1-.46-.15-.65.15-.2.29-.75.93-.92 1.12-.17.2-.34.22-.63.08-.29-.15-1.22-.45-2.32-1.44-.86-.76-1.44-1.7-1.6-1.99-.17-.29-.02-.44.13-.59.13-.13.29-.34.44-.51.15-.17.2-.29.29-.49.1-.2.05-.37-.02-.51-.08-.15-.65-1.58-.9-2.16-.24-.57-.48-.5-.65-.5-.17-.01-.37-.01-.56-.01-.2 0-.51.07-.78.37-.26.29-1.02 1-1.02 2.43 0 1.43 1.05 2.82 1.19 3.01.15.2 2.06 3.15 5 4.42.7.3 1.24.48 1.67.61.7.22 1.34.19 1.84.11.56-.08 1.7-.7 1.94-1.37.24-.68.24-1.26.17-1.38-.07-.12-.26-.2-.55-.35ZM12.02 22h-.01a9.98 9.98 0 0 1-5.09-1.4l-.36-.22-3.79.99 1.01-3.7-.24-.38A9.94 9.94 0 0 1 2 12.06C2 6.51 6.5 2 12.02 2c2.67 0 5.18 1.04 7.07 2.93A9.93 9.93 0 0 1 22 12.07c0 5.55-4.5 10.06-9.98 9.93Zm8.5-18.44A11.9 11.9 0 0 0 12.02 0C5.4 0 .04 5.4.04 12.06c0 2.13.56 4.2 1.62 6.03L0 24l6.06-1.59a11.9 11.9 0 0 0 5.95 1.6h.01c6.62 0 12-5.4 12-12.06a12 12 0 0 0-3.5-8.4Z"/></svg>
        </a>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© 2026 SDIT Rahmaniyah.</span>
    <span>Bercahaya bersama SDIT Rahmaniyah</span>
  </div>
</footer>

<script src="js/script.js"></script>

</body>
</html>
